<!doctype html>
<html lang="en">
    <head></head>
<body>
<script>
    window.localStorage.clear();
</script>
</body>
</html>
<?php
header("Location: ../loginPage.html.php"); 
exit();
?>