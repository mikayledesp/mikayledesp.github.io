# Open Pages Documentation File 
# Name: Mikayle Despaigne 

## Abiut App and How to Use it:
Open page is a community based journaling app. In the web app, registered users can post to their own private journal or they can go to the community tab to make blog posts for all registed users to see. All users can also go to the resources tab which details dfferent mental health resources.

How to use : First you must login in on the loginPage.html.php, then u get put onto the main page where you can press either "post and entry" that can be deleted under manage entries. Or, you can go to the communities tab and wrote a community post. 

If you are an admin you can press the admin link at the botton of the Login Page and use the password Admin1. With the password, you can dleetd users and delete all posts in the community tab.


## How I am meeting requirements :

 ### JavaScript Graphics: 
 logo on Bottom of resources page

 ### Dynamic Programming: 
 posts on both the journal entries would be loaded in dynamically
 ### PHP and JS Usage: 
Using php to handle the data of the users specifically and within the admin only site to see users 

Using java script for button and modal aniomations on posts and login forms 
 ### Researched feature: 
 Bootstrap

 ### Interactive Feautre 
Light and dark mode via button on site  

Admin  can be acessed on main page and deletes users 

 ### Local Communication : 
 Being able to delete and post data entries which communicated from server to clientside 



## Homeworks Refrenced : 

For this homework, I refrenced Homeowrk 9 the most as i used int to build the modal login and store users in my jSon file. I then used the same homework to inou the posts for the journal and community tab into json files that go into the folders for each user. Fo loading in the posts dynamically using JS I refrenced Homework 7/8. 


## Resources Used :

https://www.w3schools.com/js/js_api_fetch.asp
https://www.w3schools.com/js/js_window.asp
https://www.w3schools.com/php/php_form_validation.asp 
https://stackoverflow.com/questions/18213026/delete-element-from-json-with-php 